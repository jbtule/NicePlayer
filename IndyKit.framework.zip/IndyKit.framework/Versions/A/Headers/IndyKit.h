/*
 *  IndyKit.h
 *  IndyKit
 *
 *  Created by James Tuley on Fri Jun 18 2004.
 *  Copyright (c) 2004 James Tuley. All rights reserved.
 *
 */

#import <IndyKit/IndyAppKit.h>
#import <IndyKit/IndyFoundation.h>
