//
//  NSToolbar-JTAddition.h
//  IndyKit
//
//  Created by James Tuley on Sat Jul 17 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <cocoa/cocoa.h>


@interface NSToolbar (JTAdditions)

-(IBAction)resetToolbarToDefaults:(id)sender;

@end
