//
//  JTPublicCryptKey.h
//  IndyKit
//
//  Created by James Tuley on Tue Jul 20 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <IndyKit/IndyFoundation.h>

@interface JTPublicCryptKey : JTCryptKey {

}

-(BOOL)verifyData:(NSData*)aData withSignature:(NSData*)aSig;


@end
