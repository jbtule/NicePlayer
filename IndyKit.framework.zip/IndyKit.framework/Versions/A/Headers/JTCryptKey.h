//
//  JTCryptKey.h
//  IndyKit
//
//  Created by James Tuley on Tue Jul 20 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <security/security.h>

#define JTPublicKey @"Public"
#define JTPrivateKey @"Private"

@interface JTCryptKey : NSObject {
    CSSM_CSP_HANDLE _cspHandle;
    CSSM_KEY _key;

}
-(BOOL)writeToFile:(NSString*)aPath atomically:(BOOL)flag;
+(id)keyWithKey:(CSSM_KEY_PTR)aKey andHandle:(CSSM_CSP_HANDLE)aCSPHandle;
-(id)initWithKey:(CSSM_KEY_PTR)aKey andHandle:(CSSM_CSP_HANDLE)aCSPHandle;
-(uint32)type;

-(uint32)signitureAlgorithm;
@end
