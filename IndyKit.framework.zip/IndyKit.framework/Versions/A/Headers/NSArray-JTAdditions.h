//
//  NSArray-JTAdditions.h
//  NicePlayer
//
//  Created by James Tuley on Tue Jun 15 2004.
//  Copyright (c) 2004 James Tuley. All rights reserved.
//

#import <Foundation/Foundation.h>
#define NSArrayPair(a,b) [NSArray arrayWithObjects:a,b,nil]
#define NSArrayTrio(a,b,c) [NSArray arrayWithObjects:a,b,c,nil]


@interface NSArray (JTAdditions)

+(id)arrayWithNumbersForRange:(NSRange)aRange;
+(id)arrayWithNumbersForRange:(NSRange)aRange overInterval:(double)anInterval;

-(id)initWithNumbersForRange:(NSRange)aRange;
-(id)initWithNumbersForRange:(NSRange)aRange overInterval:(double)anInterval;

-(id)firstObject;
-(id)secondObject;

-(BOOL)isEmpty;
-(BOOL)notEmpty;

- (NSArray *)collectUsingFunction:(id (*)(id, void *))modifingFunction context:(void *)context;
- (NSArray *)selectUsingFunction:(BOOL (*)(id, void *))selectingFunction context:(void *)context;
- (NSArray *)rejectUsingFunction:(BOOL (*)(id, void *))selectingFunction context:(void *)context;
- (id)detectUsingFunction:(BOOL (*)(id, void *))selectingFunction context:(void *)context;
- (id)injectUsingFunction:(id (*)(id, id, void *))injectingFunction into:(id)object context:(void *)context;


@end
