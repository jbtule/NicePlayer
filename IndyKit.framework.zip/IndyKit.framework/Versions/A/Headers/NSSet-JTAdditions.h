//
//  NSSet-JTAdditions.h
//  IndyKit
//
//  Created by James Tuley on Fri Jun 18 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSSet(JTAdditions)

-(BOOL)isEmpty;
-(BOOL)notEmpty;

- (NSSet *)collectUsingFunction:(id (*)(id, void *))modifingFunction context:(void *)context;
- (NSSet *)selectUsingFunction:(BOOL (*)(id, void *))selectingFunction context:(void *)context;
- (NSSet *)rejectUsingFunction:(BOOL (*)(id, void *))selectingFunction context:(void *)context;
- (id)detectUsingFunction:(BOOL (*)(id, void *))selectingFunction context:(void *)context;
- (id)injectUsingFunction:(id (*)(id, id, void *))injectingFunction into:(id)object context:(void *)context;

@end
