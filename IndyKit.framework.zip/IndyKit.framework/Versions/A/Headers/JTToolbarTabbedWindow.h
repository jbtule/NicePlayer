//
//  JTToolbarTabbedWindow.h
//  IndyKit
//
//  Created by James Tuley on 8/29/04.
//  Copyright 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface JTToolbarTabbedWindow : NSWindow {

}

@end
