//
//  TenThreeCompatibility.h
//  CocoaScriptMenu
//
//  Created by James Tuley on 10/10/05.
//  Copyright 2005 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


#ifndef MAC_OS_X_VERSION_MIN_REQUIRED
#define MAC_OS_X_VERSION_MIN_REQUIRED MAC_OS_X_VERSION_10_3
#endif

//Weak link the variable constants used
/*extern const CFStringRef kUTTypeApplication __attribute__((weak_import));
extern const CFStringRef kUTTypeFolder __attribute__((weak_import));
extern const CFStringRef kUTTypeVolume __attribute__((weak_import));*/

//function to check for mising weak constants
extern id TTCConstantIfAvailible(void** aConst, id aKnownValue);


//variables to make up for missing ones in 10.3
extern NSSearchPathDirectory TTCApplicationSupportDirectory;


//Use Instead of NSSearchPathForDirectoriesInDomains
extern NSArray* TTCSearchPathForDirectoriesInDomains (NSSearchPathDirectory directory, NSSearchPathDomainMask domainMask, BOOL expandTilde);

extern BOOL TTCRunningLessThan10_4O();

        
        
        
